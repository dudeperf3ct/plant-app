__version__ = "0.6.0"
__title__ = "pygbif"
__author__ = "Scott Chamberlain"
__license__ = "MIT"
